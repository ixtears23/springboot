### 스프링 부트 CLI

다음 명령어를 실행하세요.

```java
spring run *.java
```


