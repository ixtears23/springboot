insert into PERSON (last_name, first_name) values ('김','창수');
insert into PERSON (last_name, first_name) values ('박','지영');
insert into PERSON (last_name, first_name) values ('유','광준');