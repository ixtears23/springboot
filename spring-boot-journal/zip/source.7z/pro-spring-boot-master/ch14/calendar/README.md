# 캘린더 앱
이 앱은 journal-spring-boot-starter pom을 사용합니다.

프로젝트 초기화
```bash
$ spring init -name=spring-boot-calendar --package=com.apress.spring -g=com.apress.spring -a=spring-boot-calendar -x
```
